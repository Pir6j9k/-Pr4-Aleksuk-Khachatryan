﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using Практическая_работа_4_Алексюк_Хачатрян.Logic;

namespace MathFun
{
    [TestClass]
    public class SecondPageTests
    {
        [TestMethod]
        public void TryParseValues_ValidValues_ReturnsTrue()
        {
            bool result = SecondPageCalculator.TryParseValues("2", "3", out double x, out double b);
            Assert.IsTrue(result);
        }

        [TestMethod]
        public void TryParseVales_EmptyString_ReturnsFalse()
        {
            bool result = SecondPageCalculator.TryParseValues("", "2", out _, out _);
            Assert.IsFalse(result);
        }

        [TestMethod]
        public void TryParseVales_Letters_ReturnsFalse()
        {
            bool result = SecondPageCalculator.TryParseValues("abc", "3", out _, out _);
            Assert.IsFalse(result);
        }

        [TestMethod]
        public void TryParseVales_Symbols_ReturnsFalse()
        {
            bool result = SecondPageCalculator.TryParseValues("@#", "4", out _, out _);
            Assert.IsFalse(result);
        }

        [TestMethod]
        public void CalculateFx_Sinh_ReturnsCorrectValue()
        {
            double result = SecondPageCalculator.CalculateFx(1, FxType.Sinh);

            Assert.AreEqual(Math.Sinh(1), result, 0.0001);
        }

        [TestMethod]
        public void CalculateFx_Square_ReturnsCorrectValue()
        {
            double result = SecondPageCalculator.CalculateFx(3, FxType.Square);

            Assert.AreEqual(9, result);
        }

        [TestMethod]
        public void CalculateFx_Exp_ReturnsCorrectValue()
        {
            double result = SecondPageCalculator.CalculateFx(2, FxType.Exp);

            Assert.AreEqual(Math.Exp(2), result, 0.0001);
        }

        [TestMethod]
        public void Calculate_Range1_ReturnsExp()
        {
            double x = 2;
            double b = 2;

            double result = SecondPageCalculator.Calculate(x, b, FxType.Square);

            Assert.IsTrue(result > 0);
        }

        [TestMethod]
        public void Calculate_Range2_ReturnsSqrt()
        {
            double x = 5;
            double b = 3;

            double result = SecondPageCalculator.Calculate(x, b, FxType.Sinh);

            Assert.IsTrue(result >= 0);
        }

        [TestMethod]
        public void Calculate_DefaultBranch_ReturnsCorrect()
        {
            double x = 0.5;
            double b = 1;

            double result = SecondPageCalculator.Calculate(x, b, FxType.Exp);

            Assert.IsTrue(result >= 0);
        }
    }
}
