﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using Практическая_работа_4_Алексюк_Хачатрян.Logic;

namespace MathFun
{
    [TestClass]
    public class FirstPageTests
    {
        [TestMethod]
        public void TryParseVales_ValidNmbers_ReturnsTrue()
        {
            bool result = FirstPageCalculator.TryParseValues("2", "1", "3", out double x, out double y, out double z);
            Assert.IsTrue(result);
        }

        [TestMethod]
        public void TryParseVales_EmptyString_ReturnsFalse()
        {
            bool result = FirstPageCalculator.TryParseValues("", "1", "3", out _, out _, out _);
            Assert.IsFalse(result);
        }

        [TestMethod]
        public void TryParseVales_Letters_ReturnsFalse()
        {
            bool result = FirstPageCalculator.TryParseValues("abc", "1", "3", out _, out _, out _);
            Assert.IsFalse(result);
        }

        [TestMethod]
        public void TryParseVales_Symbols_ReturnsFalse()
        {
            bool result = FirstPageCalculator.TryParseValues("@#", "1", "3", out _, out _, out _);
            Assert.IsFalse(result);
        }

        [TestMethod]
        public void Calculate_NormalValues_ReturnsCorrectResult()
        {
            double x = 2;
            double y = 1;
            double z = 3;

            double result = FirstPageCalculator.Calculate(x, y, z);

            double expected = 5 * Math.Atan(x) - (1.0 / 4.0) * Math.Atan(x) * ((x + 3 * Math.Abs(x - y) + Math.Pow(x, 2)) / (Math.Abs(x - y) * z + Math.Pow(x, 2)));

            Assert.AreEqual(expected, result);
        }

        [TestMethod]
        public void Calculate_NegativeValues_ReturnsCorrectResult()
        {
            double x = -2;
            double y = -1;
            double z = 4;

            double result = FirstPageCalculator.Calculate(x, y, z);

            Assert.IsTrue(!double.IsNaN(result));
        }

        [TestMethod]
        public void Calculate_ZeroValues_ReturnsCorrectResult()
        {
            double x = 0;
            double y = 1;
            double z = 1;

            double result = FirstPageCalculator.Calculate(x, y, z);

            Assert.IsTrue(!double.IsNaN(result));
        }

        [TestMethod]
        [ExpectedException(typeof(DivideByZeroException))] 
        public void Calculate_DivideByZero_ThrowException()
        {
            double x = 0;
            double y = 0;
            double z = 0;

            FirstPageCalculator.Calculate(x, y, z);
        }

        [TestMethod]
        public void Calculate_LargeNumbers_WorksCorrectly()
        {
            double x = 1000;
            double y = 700;
            double z = 400;

            double result = FirstPageCalculator.Calculate(x, y,z);

            Assert.IsTrue(!double.IsInfinity(result));
        }
    }
}
